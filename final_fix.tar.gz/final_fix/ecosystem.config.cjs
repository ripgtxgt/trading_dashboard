/**
 * PM2 Configuration File
 * Manages all service processes
 */

module.exports = {
  apps: [
    // Web Dashboard (Node.js + tRPC Server)
    {
      name: 'trading-dashboard',
      script: 'server/_core/index.ts',
      interpreter: 'node',
      interpreter_args: '--loader tsx',
      cwd: './',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: './logs/dashboard-error.log',
      out_file: './logs/dashboard-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    },

    // Trading Bot (V24 Strategy)
    {
      name: 'trading-bot',
      script: 'scripts/v24_strategy.py',
      interpreter: 'python',
      cwd: './',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '300M',
      error_file: './logs/trading-bot-error.log',
      out_file: './logs/trading-bot-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      autostart: true,
    },

    // Telegram Bot
    {
      name: 'telegram-bot',
      script: 'scripts/telegram_bot.py',
      interpreter: 'python',
      cwd: './',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '200M',
      error_file: './logs/telegram-bot-error.log',
      out_file: './logs/telegram-bot-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      autostart: true,
    },

    // WebSocket Server
    {
      name: 'websocket-server',
      script: 'scripts/websocket_server.py',
      interpreter: 'python',
      cwd: './',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '200M',
      error_file: './logs/websocket-error.log',
      out_file: './logs/websocket-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      autostart: true,
    },

    // Daily Report Scheduler
    {
      name: 'daily-report',
      script: 'scripts/daily_report.py',
      interpreter: 'python',
      cwd: './',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '200M',
      error_file: './logs/daily-report-error.log',
      out_file: './logs/daily-report-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      autostart: true,
      cron_restart: '0 0 * * *',
    },
  ],
};
