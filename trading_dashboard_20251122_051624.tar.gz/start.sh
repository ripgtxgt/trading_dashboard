#!/bin/bash

echo "=========================================="
echo "10U战神滚仓策略 - 快速启动"
echo "=========================================="
echo ""

# 检查依赖
if ! command -v node &> /dev/null; then
    echo "❌ Node.js未安装"
    exit 1
fi

if ! command -v pnpm &> /dev/null; then
    echo "❌ pnpm未安装"
    exit 1
fi

if ! command -v python3 &> /dev/null; then
    echo "❌ Python3未安装"
    exit 1
fi

echo "✅ 环境检查通过"
echo ""

# 检查是否已安装依赖
if [ ! -d "node_modules" ]; then
    echo "📦 安装Node.js依赖..."
    pnpm install
    echo ""
fi

# 启动开发服务器
echo "🚀 启动开发服务器..."
echo ""
echo "访问: http://localhost:3000"
echo "按 Ctrl+C 停止服务"
echo ""

pnpm dev
