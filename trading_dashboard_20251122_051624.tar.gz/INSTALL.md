# 安装指南

## 1. 环境要求

- Node.js 22+
- Python 3.11+
- MySQL 8.0+ (或TiDB)
- pnpm

## 2. 安装步骤

### 2.1 安装Node.js依赖

```bash
pnpm install
```

### 2.2 安装Python依赖

```bash
pip3 install ccxt pandas numpy python-telegram-bot websockets
```

### 2.3 配置环境变量

创建 `.env` 文件（或通过Manus平台配置）：

```env
# 数据库
DATABASE_URL=mysql://user:password@host:port/database

# OAuth (如果使用Manus平台，这些会自动注入)
JWT_SECRET=your_jwt_secret
VITE_APP_ID=your_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://auth.manus.im

# Manus API (如果使用Manus平台，这些会自动注入)
BUILT_IN_FORGE_API_KEY=your_api_key
BUILT_IN_FORGE_API_URL=https://api.manus.im
```

### 2.4 配置交易API

编辑 `scripts/config.py`：

```python
# KuCoin API配置
API_KEY = "your_kucoin_api_key"
API_SECRET = "your_kucoin_api_secret"
API_PASSPHRASE = "your_kucoin_passphrase"

# Telegram配置（可选）
TELEGRAM_BOT_TOKEN = "your_telegram_bot_token"
TELEGRAM_CHAT_ID = "your_telegram_chat_id"
```

### 2.5 初始化数据库

```bash
pnpm db:push
```

## 3. 启动服务

### 3.1 启动Web服务

```bash
pnpm dev
```

访问: http://localhost:3000

### 3.2 启动WebSocket服务（可选）

```bash
python3 scripts/websocket_pusher.py
```

### 3.3 启动交易机器人（可选）

```bash
python3 scripts/trading_bot.py
```

## 4. 首次使用

1. 访问Dashboard并登录
2. 启用"测试模式"
3. 使用"策略向导"优化参数
4. 在测试模式下验证策略
5. 确认无误后切换到实盘

## 5. 故障排除

查看 `README.md` 中的故障排除章节。

---

**重要提示**: 请先在测试模式下充分验证系统功能，再进行实盘交易！
