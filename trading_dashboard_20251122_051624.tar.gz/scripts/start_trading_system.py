#!/usr/bin/env python3
"""
10U战神滚仓策略 - Web Dashboard集成版
完整集成数据库同步和Telegram通知功能
"""

import os
import sys
import time
import logging
from datetime import datetime

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from live_strategy_engine_rolling import LiveStrategyEngineRolling
from kucoin_trader import KuCoinTrader
from live_trading_config import STRATEGY_CONFIG
from db_sync import DatabaseSync
from telegram_notifier import TelegramNotifier
from risk_manager import RiskManager


# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'trading_system_{datetime.now().strftime("%Y%m%d")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('TradingSystem')


class IntegratedTradingSystem:
    """集成版交易系统"""
    
    def __init__(self):
        """初始化系统"""
        logger.info("="*60)
        logger.info("10U战神滚仓策略 - Web Dashboard集成版")
        logger.info("="*60)
        
        # 检查环境变量
        self.check_env_vars()
        
        # 初始化数据库连接
        self.db = DatabaseSync()
        if not self.db.connect():
            logger.error("数据库连接失败！")
            sys.exit(1)
        
        # 初始化Telegram通知
        self.telegram = TelegramNotifier()
        
        # 初始化风险管理器
        self.risk_manager = RiskManager()
        logger.info("风险管理模块已启动")
        
        # 初始化KuCoin交易器
        api_key = os.getenv('KUCOIN_API_KEY')
        api_secret = os.getenv('KUCOIN_API_SECRET')
        api_passphrase = os.getenv('KUCOIN_API_PASSPHRASE')
        
        if not all([api_key, api_secret, api_passphrase]):
            logger.error("缺少KuCoin API配置！")
            logger.error("请设置环境变量：KUCOIN_API_KEY, KUCOIN_API_SECRET, KUCOIN_API_PASSPHRASE")
            sys.exit(1)
        
        self.trader = KuCoinTrader(
            api_key=api_key,
            api_secret=api_secret,
            api_passphrase=api_passphrase,
            is_sandbox=os.getenv('KUCOIN_SANDBOX', 'false').lower() == 'true'
        )
        
        # 初始化策略引擎
        self.engine = LiveStrategyEngineRolling(
            trader=self.trader,
            initial_capital=float(os.getenv('INITIAL_CAPITAL', '10.0'))
        )
        
        # 将数据库和Telegram集成到引擎
        self.engine.db = self.db
        self.telegram = self.telegram
        
        # 修改引擎的开仓方法，添加数据库同步
        self._patch_engine_methods()
        
        logger.info("系统初始化完成")
        logger.info(f"初始资金: {self.engine.capital:.2f} USDT")
        logger.info(f"当前阶段: {self.engine.rolling_manager.get_current_stage(self.engine.capital).name}")
    
    def check_env_vars(self):
        """检查必需的环境变量"""
        required_vars = {
            'DATABASE_URL': '数据库连接字符串',
            'KUCOIN_API_KEY': 'KuCoin API Key',
            'KUCOIN_API_SECRET': 'KuCoin API Secret',
            'KUCOIN_API_PASSPHRASE': 'KuCoin API Passphrase'
        }
        
        missing_vars = []
        for var, desc in required_vars.items():
            if not os.getenv(var):
                missing_vars.append(f"  {var} - {desc}")
        
        if missing_vars:
            logger.error("缺少必需的环境变量：")
            for var in missing_vars:
                logger.error(var)
            logger.error("\n可选环境变量：")
            logger.error("  TELEGRAM_BOT_TOKEN - Telegram Bot Token")
            logger.error("  TELEGRAM_CHAT_ID - Telegram Chat ID")
            logger.error("  KUCOIN_SANDBOX - 是否使用沙盒环境（true/false）")
            logger.error("  INITIAL_CAPITAL - 初始资金（默认10.0）")
            sys.exit(1)
    
    def _patch_engine_methods(self):
        """修改引擎方法，添加数据库同步和Telegram通知"""
        
        # 保存原始方法
        original_open_position = self.engine.open_position
        original_close_position = self.engine.rolling_manager.close_position
        
        def patched_open_position(direction):
            """开仓（添加数据库同步和通知）"""
            result = original_open_position(direction)
            
            if result and self.engine.rolling_manager.current_position:
                pos = self.engine.rolling_manager.current_position
                
                # 同步到数据库
                try:
                    position_id = self.db.update_position(
                        symbol='XBTUSDTM',
                        side=pos.side,
                        entry_price=pos.entry_price,
                        quantity=pos.size,
                        margin=pos.margin,
                        leverage=self.trader.leverage
                    )
                    logger.info(f"持仓已同步到数据库，ID: {position_id}")
                except Exception as e:
                    logger.error(f"持仓同步失败: {e}")
                
                # 发送Telegram通知
                try:
                    self.telegram.send_trade_opened(
                        symbol='XBTUSDTM',
                        side=pos.side,
                        price=pos.entry_price,
                        quantity=pos.size,
                        margin=pos.margin
                    )
                except Exception as e:
                    logger.error(f"Telegram通知发送失败: {e}")
            
            return result
        
        def patched_close_position(current_price, reason=""):
            """平仓（添加数据库同步和通知）"""
            pos = self.engine.rolling_manager.current_position
            if not pos:
                return None
            
            # 保存平仓前的数据
            entry_price = pos.entry_price
            size = pos.size
            side = pos.side
            margin = pos.margin
            
            # 执行平仓
            result = original_close_position(current_price, reason)
            
            if result:
                # 记录到风险管理器
                self.risk_manager.record_trade(
                    pnl=result['pnl'],
                    is_win=result['pnl'] > 0
                )
                
                # 同步到数据库
                try:
                    trade_id = self.db.add_trade(
                        symbol='XBTUSDTM',
                        side=side,
                        entry_price=entry_price,
                        exit_price=current_price,
                        quantity=size,
                        pnl=result['pnl'],
                        pnl_percent=result['pnl_pct'],
                        open_time=datetime.now(),  # 简化处理
                        close_time=datetime.now()
                    )
                    logger.info(f"交易已同步到数据库，ID: {trade_id}")
                    
                    # 更新机器人状态
                    self.db.update_bot_state(
                        status='running',
                        current_balance=self.engine.capital,
                        total_trades=len(self.engine.rolling_manager.trade_history),
                        win_trades=sum(1 for t in self.engine.rolling_manager.trade_history if t.get('pnl', 0) > 0),
                        total_profit=self.engine.capital - self.engine.initial_capital
                    )
                    
                    # 添加资金快照
                    self.db.add_balance_snapshot(
                        balance=self.engine.capital,
                        equity=self.engine.capital,
                        margin_used=0.0
                    )
                    
                except Exception as e:
                    logger.error(f"交易同步失败: {e}")
                
                # 发送Telegram通知
                try:
                    self.telegram.send_trade_closed(
                        symbol='XBTUSDTM',
                        side=side,
                        entry_price=entry_price,
                        exit_price=current_price,
                        pnl=result['pnl'],
                        pnl_percent=result['pnl_pct']
                    )
                except Exception as e:
                    logger.error(f"Telegram通知发送失败: {e}")
            
            return result
        
        # 替换方法
        self.engine.open_position = patched_open_position
        self.engine.rolling_manager.close_position = patched_close_position
    
    def run(self):
        """运行交易系统"""
        logger.info("交易系统启动")
        
        # 发送启动通知
        try:
            self.telegram.send_bot_status(
                status="启动",
                balance=self.engine.capital,
                total_trades=0,
                win_rate=0.0
            )
        except Exception as e:
            logger.error(f"Telegram通知发送失败: {e}")
        
        # 更新数据库状态
        try:
            self.db.update_bot_state(
                status='running',
                current_balance=self.engine.capital,
                total_trades=0,
                win_trades=0,
                total_profit=0.0
            )
        except Exception as e:
            logger.error(f"数据库更新失败: {e}")
        
        try:
            # 启动策略引擎
            self.engine.is_running = True
            
            while self.engine.is_running and not self.engine.emergency_stopped:
                try:
                    # 获取当前价格
                    current_price = self.trader.get_current_price()
                    if not current_price:
                        logger.warning("无法获取当前价格")
                        time.sleep(60)
                        continue
                    
                    # 风险检查
                    allowed, reason = self.risk_manager.check_risk(current_price, self.engine.capital)
                    
                    if not allowed:
                        logger.warning(f"交易被暂停: {reason}")
                        
                        # 发送风险警告
                        try:
                            risk_status = self.risk_manager.get_risk_status()
                            self.telegram.send_risk_alert(
                                alert_type=reason,
                                current_balance=self.engine.capital,
                                drawdown=risk_status['current_drawdown_pct'],
                                consecutive_losses=risk_status['consecutive_losses']
                            )
                        except Exception as e:
                            logger.error(f"Telegram通知发送失败: {e}")
                        
                        # 如果有持仓，考虑平仓
                        if self.engine.rolling_manager.current_position:
                            logger.info("检测到持仓，执行平仓...")
                            self.engine.rolling_manager.close_position(current_price, f"风险控制: {reason}")
                        
                        # 等待一段时间再检查
                        time.sleep(300)  # 5分钟
                        continue
                    
                    # 执行一个交易周期
                    self.engine.run_cycle()
                    
                    # 等待下一个周期
                    time.sleep(self.engine.check_interval)
                    
                except KeyboardInterrupt:
                    logger.info("\n收到停止信号...")
                    break
                except Exception as e:
                    logger.error(f"交易周期出错: {e}", exc_info=True)
                    time.sleep(60)  # 出错后等待1分钟再继续
        
        finally:
            self.shutdown()
    
    def shutdown(self):
        """关闭系统"""
        logger.info("="*60)
        logger.info("交易系统停止")
        logger.info("="*60)
        
        # 如果有持仓，平仓
        if self.engine.rolling_manager.current_position:
            logger.info("检测到持仓，执行平仓...")
            current_price = self.trader.get_current_price()
            if current_price:
                self.engine.rolling_manager.close_position(current_price, "系统停止")
        
        # 打印统计信息
        total_trades = len(self.engine.rolling_manager.trade_history)
        if total_trades > 0:
            win_trades = sum(1 for t in self.engine.rolling_manager.trade_history if t.get('pnl', 0) > 0)
            win_rate = (win_trades / total_trades) * 100
            total_profit = self.engine.capital - self.engine.initial_capital
            
            logger.info(f"总交易次数: {total_trades}")
            logger.info(f"盈利次数: {win_trades}")
            logger.info(f"胜率: {win_rate:.2f}%")
            logger.info(f"总盈亏: {total_profit:.2f} USDT")
            logger.info(f"最终余额: {self.engine.capital:.2f} USDT")
            logger.info(f"收益率: {((self.engine.capital - self.engine.initial_capital) / self.engine.initial_capital * 100):.2f}%")
            
            # 发送每日统计
            try:
                self.telegram.send_daily_summary(
                    total_trades=total_trades,
                    win_trades=win_trades,
                    win_rate=win_rate,
                    total_pnl=total_profit,
                    current_balance=self.engine.capital
                )
            except Exception as e:
                logger.error(f"Telegram通知发送失败: {e}")
        
        # 更新数据库状态
        try:
            self.db.update_bot_state(
                status='stopped',
                current_balance=self.engine.capital,
                total_trades=total_trades,
                win_trades=win_trades if total_trades > 0 else 0,
                total_profit=total_profit if total_trades > 0 else 0.0
            )
        except Exception as e:
            logger.error(f"数据库更新失败: {e}")
        
        # 断开数据库连接
        self.db.disconnect()
        
        logger.info("="*60)


def main():
    """主函数"""
    system = IntegratedTradingSystem()
    system.run()


if __name__ == "__main__":
    main()
