"""
KuCoin Futures API 原生封装
版本: 3.0 (无第三方broker ID)
不依赖CCXT，直接调用KuCoin官方API
"""
import hmac
import hashlib
import base64
import time
import requests
import json
import logging
from typing import Optional, Dict, List, Any


class KuCoinFuturesAPI:
    """KuCoin合约API封装类"""
    
    def __init__(self, api_key: str, api_secret: str, api_passphrase: str, sandbox: bool = False):
        """
        初始化KuCoin API
        
        Args:
            api_key: API Key
            api_secret: API Secret
            api_passphrase: API Passphrase
            sandbox: 是否使用沙盒环境
        """
        self.logger = logging.getLogger('KuCoinAPI')
        self.api_key = api_key
        self.api_secret = api_secret
        self.api_passphrase = api_passphrase
        
        # API基础URL
        if sandbox:
            self.base_url = "https://api-sandbox-futures.kucoin.com"
        else:
            self.base_url = "https://api-futures.kucoin.com"
        
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': 'KuCoin-Futures-Python-SDK/3.0'
        })
    
    def _generate_signature(self, timestamp: str, method: str, endpoint: str, body: str = '') -> tuple:
        """
        生成API签名
        
        Args:
            timestamp: 时间戳（毫秒）
            method: 请求方法 (GET/POST/DELETE)
            endpoint: API端点
            body: 请求体（JSON字符串）
            
        Returns:
            (signature, passphrase)
        """
        # 构造待签名字符串
        str_to_sign = timestamp + method + endpoint + body
        
        # 生成签名
        signature = base64.b64encode(
            hmac.new(
                self.api_secret.encode('utf-8'),
                str_to_sign.encode('utf-8'),
                hashlib.sha256
            ).digest()
        ).decode('utf-8')
        
        # 加密passphrase
        passphrase = base64.b64encode(
            hmac.new(
                self.api_secret.encode('utf-8'),
                self.api_passphrase.encode('utf-8'),
                hashlib.sha256
            ).digest()
        ).decode('utf-8')
        
        return signature, passphrase
    
    def _request(self, method: str, endpoint: str, params: Optional[Dict] = None, data: Optional[Dict] = None) -> Dict:
        """
        发送API请求
        
        Args:
            method: 请求方法
            endpoint: API端点
            params: URL参数
            data: 请求体数据
            
        Returns:
            响应数据
        """
        # 生成时间戳
        timestamp = str(int(time.time() * 1000))
        
        # 构造请求体
        body = ''
        if data:
            body = json.dumps(data)
        
        # 对于GET和DELETE请求，需要将params拼接到endpoint中进行签名
        sign_endpoint = endpoint
        if method in ['GET', 'DELETE'] and params:
            query_string = '&'.join([f"{k}={v}" for k, v in sorted(params.items())])
            sign_endpoint = f"{endpoint}?{query_string}"
        
        # 生成签名
        signature, passphrase = self._generate_signature(timestamp, method, sign_endpoint, body)
        
        # 构造请求头
        headers = {
            'KC-API-KEY': self.api_key,
            'KC-API-SIGN': signature,
            'KC-API-TIMESTAMP': timestamp,
            'KC-API-PASSPHRASE': passphrase,
            'KC-API-KEY-VERSION': '2'
        }
        
        # 发送请求
        url = self.base_url + endpoint
        
        self.logger.debug(f"API请求: {method} {url}")
        if params:
            self.logger.debug(f"  参数: {params}")
        if data:
            self.logger.debug(f"  数据: {data}")
        
        try:
            if method == 'GET':
                response = self.session.get(url, headers=headers, params=params, timeout=10)
            elif method == 'POST':
                response = self.session.post(url, headers=headers, json=data, timeout=10)
            elif method == 'DELETE':
                response = self.session.delete(url, headers=headers, params=params, timeout=10)
            else:
                raise ValueError(f"不支持的请求方法: {method}")
            
            self.logger.debug(f"  响应状态: {response.status_code}")
            
            response.raise_for_status()
            result = response.json()
            
            # 检查API返回的code
            if result.get('code') != '200000':
                error_msg = f"KuCoin API错误: {result.get('msg', 'Unknown error')}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
            
            self.logger.debug(f"  请求成功")
            return result.get('data', {})
            
        except requests.exceptions.RequestException as e:
            error_msg = f"API请求失败: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
    
    # ==================== 账户相关 ====================
    
    def get_account_overview(self, currency: str = 'USDT') -> Dict:
        """
        获取账户概览
        
        Args:
            currency: 币种（默认USDT）
            
        Returns:
            账户信息
        """
        endpoint = f'/api/v1/account-overview'
        params = {'currency': currency}
        return self._request('GET', endpoint, params=params)
    
    def get_balance(self, currency: str = 'USDT') -> float:
        """
        获取可用余额
        
        Args:
            currency: 币种
            
        Returns:
            可用余额
        """
        account = self.get_account_overview(currency)
        return float(account.get('availableBalance', 0))
    
    # ==================== 市场数据 ====================
    
    def get_klines(self, symbol: str, granularity: int, from_time: Optional[int] = None, to_time: Optional[int] = None) -> List[List]:
        """
        获取K线数据
        
        Args:
            symbol: 合约代码，如 'XBTUSDTM'
            granularity: K线周期（分钟）: 1, 5, 15, 30, 60, 120, 240, 480, 720, 1440, 10080
            from_time: 开始时间（秒级时间戳）
            to_time: 结束时间（秒级时间戳）
            
        Returns:
            K线数据列表 [[时间, 开, 高, 低, 收, 成交量], ...]
        """
        endpoint = f'/api/v1/kline/query'
        params = {
            'symbol': symbol,
            'granularity': granularity
        }
        
        # KuCoin需要毫秒级时间戳，且from/to都是必须的
        if not to_time:
            to_time = int(time.time())
        if not from_time:
            from_time = to_time - (200 * granularity * 60)  # 默认200条
        
        params['from'] = from_time * 1000  # 转毫秒
        params['to'] = to_time * 1000
        
        data = self._request('GET', endpoint, params=params)
        return data if isinstance(data, list) else []
    
    def get_ticker(self, symbol: str) -> Dict:
        """
        获取实时行情
        
        Args:
            symbol: 合约代码
            
        Returns:
            行情数据
        """
        endpoint = f'/api/v1/ticker'
        params = {'symbol': symbol}
        return self._request('GET', endpoint, params=params)
    
    def get_current_price(self, symbol: str) -> float:
        """
        获取当前价格
        
        Args:
            symbol: 合约代码
            
        Returns:
            当前价格
        """
        ticker = self.get_ticker(symbol)
        return float(ticker.get('price', 0))
    
    # ==================== 持仓相关 ====================
    
    def get_position(self, symbol: str) -> Optional[Dict]:
        """
        获取持仓信息
        
        Args:
            symbol: 合约代码
            
        Returns:
            持仓信息，无持仓返回None
        """
        endpoint = f'/api/v1/position'
        params = {'symbol': symbol}
        data = self._request('GET', endpoint, params=params)
        
        # 检查是否有持仓
        if data and float(data.get('currentQty', 0)) != 0:
            return data
        return None
    
    def get_all_positions(self) -> List[Dict]:
        """
        获取所有持仓
        
        Returns:
            持仓列表
        """
        endpoint = f'/api/v1/positions'
        data = self._request('GET', endpoint)
        return data if isinstance(data, list) else []
    
    # ==================== 交易相关 ====================
    
    def set_leverage(self, symbol: str, leverage: int) -> Dict:
        """
        设置杠杆倍数
        
        Args:
            symbol: 合约代码
            leverage: 杠杆倍数
            
        Returns:
            设置结果
        """
        endpoint = f'/api/v1/position/margin/auto-deposit-status'
        data = {
            'symbol': symbol,
            'leverage': leverage
        }
        return self._request('POST', endpoint, data=data)
    
    def create_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        size: int,
        price: Optional[float] = None,
        leverage: Optional[int] = None,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        client_oid: Optional[str] = None
    ) -> Dict:
        """
        创建订单
        
        Args:
            symbol: 合约代码，如 'XBTUSDTM'
            side: 方向 'buy' 或 'sell'
            order_type: 订单类型 'limit' 或 'market'
            size: 数量（张数）
            price: 价格（限价单必填）
            leverage: 杠杆倍数
            stop_loss: 止损价
            take_profit: 止盈价
            client_oid: 客户端订单ID
            
        Returns:
            订单信息
        """
        endpoint = f'/api/v1/orders'
        
        data = {
            'symbol': symbol,
            'side': side,
            'type': order_type,
            'size': size
        }
        
        if price:
            data['price'] = price
        if leverage:
            data['leverage'] = leverage
        if stop_loss:
            data['stopLoss'] = stop_loss
        if take_profit:
            data['takeProfit'] = take_profit
        if client_oid:
            data['clientOid'] = client_oid
        else:
            data['clientOid'] = str(int(time.time() * 1000))
        
        return self._request('POST', endpoint, data=data)
    
    def cancel_order(self, order_id: str) -> Dict:
        """
        取消订单
        
        Args:
            order_id: 订单ID
            
        Returns:
            取消结果
        """
        endpoint = f'/api/v1/orders/{order_id}'
        return self._request('DELETE', endpoint)
    
    def cancel_all_orders(self, symbol: Optional[str] = None) -> Dict:
        """
        取消所有订单
        
        Args:
            symbol: 合约代码（可选，不填则取消所有）
            
        Returns:
            取消结果
        """
        endpoint = f'/api/v1/orders'
        params = {}
        if symbol:
            params['symbol'] = symbol
        return self._request('DELETE', endpoint, params=params)
    
    def get_order(self, order_id: str) -> Dict:
        """
        查询订单
        
        Args:
            order_id: 订单ID
            
        Returns:
            订单信息
        """
        endpoint = f'/api/v1/orders/{order_id}'
        return self._request('GET', endpoint)
    
    # ==================== 辅助方法 ====================
    
    def symbol_to_kucoin(self, symbol: str) -> str:
        """
        将通用symbol转换为KuCoin格式
        
        Args:
            symbol: 通用格式 'BTC/USDT:USDT'
            
        Returns:
            KuCoin格式 'XBTUSDTM'
        """
        # BTC/USDT:USDT -> XBTUSDTM
        if symbol == 'BTC/USDT:USDT':
            return 'XBTUSDTM'
        elif symbol == 'ETH/USDT:USDT':
            return 'ETHUSDTM'
        else:
            # 通用转换规则
            base = symbol.split('/')[0]
            return f"{base}USDTM"
    
    def calculate_contract_size(self, symbol: str, usdt_amount: float, price: float, leverage: int) -> int:
        """
        计算合约张数
        
        Args:
            symbol: 合约代码
            usdt_amount: USDT金额（保证金）
            price: 当前价格
            leverage: 杠杆倍数
            
        Returns:
            合约张数
        """
        # BTC合约：1张 = 0.001 BTC
        if 'XBT' in symbol or 'BTC' in symbol:
            contract_value = 0.001  # 每张价值0.001 BTC
        else:
            contract_value = 0.01  # 其他币种一般为0.01
        
        # 名义价值 = 保证金 * 杠杆
        notional_value = usdt_amount * leverage
        
        # 张数 = 名义价值 / (价格 * 合约价值)
        size = int(notional_value / (price * contract_value))
        
        return max(1, size)  # 至少1张


# 使用示例
if __name__ == "__main__":
    # 测试代码
    from live_trading_config import KUCOIN_CONFIG
    
    api = KuCoinFuturesAPI(
        api_key=KUCOIN_CONFIG['api_key'],
        api_secret=KUCOIN_CONFIG['api_secret'],
        api_passphrase=KUCOIN_CONFIG['api_passphrase'],
        sandbox=KUCOIN_CONFIG.get('sandbox', False)
    )
    
    try:
        # 测试获取余额
        balance = api.get_balance()
        print(f"✅ 账户余额: {balance} USDT")
        
        # 测试获取价格
        symbol = 'XBTUSDTM'
        price = api.get_current_price(symbol)
        print(f"✅ BTC当前价格: {price} USDT")
        
        # 测试获取K线
        klines = api.get_klines(symbol, 60, limit=5)
        print(f"✅ 获取到 {len(klines)} 条K线数据")
        
        print("\n🎉 所有测试通过！")
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
