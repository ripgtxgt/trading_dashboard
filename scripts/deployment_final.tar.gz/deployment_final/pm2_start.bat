@echo off
echo Starting all services with PM2...
echo.

cd /d C:\trading_dashboard

if not exist "logs" mkdir logs

pm2 start ecosystem.config.js

echo.
echo Service status:
pm2 list

echo.
echo Done! Press any key to exit...
pause > nul
